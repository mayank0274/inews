# iMovie

-> Solution for task : Displays movies data from a json file with filters

-> Live link : https://iotion-react-assignment.netlify.app/

-> Demo images and video in `demo` folder

# Features

1. Implemented infinite scroll for better renderinf of movies

2. Used TypeScript for type checking

3. Filter data based on language , countries and genres

4. Dark and light mode

# Run locally

1. Download and extract zip or git clone this repo.

2. Go to project root foder and run these commands

```
npm install   // for  installing dependencies

npm run dev  // start application on port 5173

```
