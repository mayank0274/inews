import React, { useEffect, useRef, useState } from "react";
import {
  Drawer,
  DrawerBody,
  DrawerFooter,
  DrawerHeader,
  DrawerOverlay,
  DrawerContent,
  DrawerCloseButton,
  Button,
  useDisclosure,
  Box,
  Tag,
  Text,
  Circle,
} from "@chakra-ui/react";

import {
  filterData,
  getAllCountries,
  getAllGenres,
  getAllLanguages,
} from "../../utlis/filterData";
import { IMoveList, IMovie } from "./MovieSection";
import { GrSort } from "react-icons/gr";

interface Props {
  setDataLength: React.Dispatch<React.SetStateAction<number>>;
  setMovies: React.Dispatch<React.SetStateAction<IMovie[] | null>>;
  moviesList: IMoveList | null;
}

export interface IConstraints {
  languages: string;
  genres: string;
  countries: string;
  [key: string]: string;
}

interface OptionsProps {
  contentArray: string[];
  title: string;
  type: string;
  setConstraints: React.Dispatch<
    React.SetStateAction<{
      languages: string;
      genres: string;
      countries: string;
    }>
  >;
  constraints: IConstraints;
}

const FilterOptions: React.FC<OptionsProps> = ({
  contentArray,
  title,
  type,
  setConstraints,
  constraints,
}) => {
  function addToConstraints(value: string) {
    const { languages, countries, genres } = constraints;
    if (type === "languages") {
      if (languages === value && languages != "") {
        setConstraints({
          ...constraints,
          languages: "",
        });
        return;
      }
      setConstraints({
        ...constraints,
        languages: value,
      });
    }

    if (type === "genres") {
      if (genres === value && genres != "") {
        setConstraints({
          ...constraints,
          genres: "",
        });
        return;
      }

      setConstraints({
        ...constraints,
        genres: value,
      });
    }

    if (type === "countries") {
      if (countries === value && countries != "") {
        setConstraints({
          ...constraints,
          countries: "",
        });
        return;
      }
      setConstraints({
        ...constraints,
        countries: value,
      });
    }
  }

  return (
    <Box>
      <Text>{title}</Text>
      <Box display="flex" flexWrap={"wrap"} gap={"9px"} my={"10px"}>
        {contentArray.map((elem: string) => {
          return (
            <Tag
              size={"md"}
              key={elem}
              borderRadius="full"
              variant="solid"
              cursor={"pointer"}
              colorScheme={constraints[type] === elem ? "green" : "gray"}
              onClick={() => {
                addToConstraints(elem);
              }}
            >
              {elem}
            </Tag>
          );
        })}
      </Box>
    </Box>
  );
};

const Filter: React.FC<Props> = ({ setDataLength, setMovies, moviesList }) => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const btnRef = useRef<HTMLButtonElement>(null);
  const [filterCount, setFilterCount] = useState<number>(0);
  const initialState: IConstraints = {
    languages: "",
    genres: "",
    countries: "",
  };
  const [constraints, setConstraints] = useState(initialState);

  // set filters
  const handleFilter = () => {
    const { countries, languages, genres } = constraints;

    // if no filter
    if (!countries && !languages && !genres) {
      return;
    }

    // set data
    let filterArr = filterData(constraints);
    setDataLength(filterArr.length);
    setMovies(filterArr);
    onClose();
  };

  // clear filter
  const clearFilter = () => {
    setConstraints(initialState);
    if (moviesList) {
      setMovies(moviesList[1]);
      setDataLength(100);
    }
    onClose();
  };

  // count number of filter specified
  const countFilter = () => {
    let count = 0;
    Object.keys(constraints).map((elem) => {
      if (constraints[elem] != "") {
        count++;
      }
    });

    setFilterCount(count);
  };

  useEffect(() => {
    countFilter();
  }, [constraints]);

  return (
    <>
      <Button
        ref={btnRef}
        colorScheme="gray"
        onClick={onOpen}
        as={"button"}
        display={"flex"}
        gap={"10px"}
      >
        <GrSort />
        <Text letterSpacing={"2.5px"}>Filter </Text>
        {filterCount > 0 && (
          <Circle size="25px" bg={"#4d5766"}>
            {filterCount}
          </Circle>
        )}
      </Button>
      <Drawer
        isOpen={isOpen}
        placement="right"
        onClose={onClose}
        finalFocusRef={btnRef}
      >
        <DrawerOverlay />
        <DrawerContent>
          <DrawerCloseButton />
          <DrawerHeader>Filter Data</DrawerHeader>

          <DrawerBody>
            <FilterOptions
              title="Languages"
              contentArray={getAllLanguages()}
              type="languages"
              setConstraints={setConstraints}
              constraints={constraints}
            />

            <FilterOptions
              title="Genres"
              contentArray={getAllGenres()}
              type="genres"
              setConstraints={setConstraints}
              constraints={constraints}
            />

            <FilterOptions
              title="Countries"
              contentArray={getAllCountries()}
              type="countries"
              setConstraints={setConstraints}
              constraints={constraints}
            />
          </DrawerBody>

          <DrawerFooter>
            <Button
              variant="outline"
              mr={3}
              onClick={() => {
                clearFilter();
              }}
              size={"md"}
            >
              Clear Filters
            </Button>
            <Button
              colorScheme="blue"
              size={"md"}
              onClick={() => {
                handleFilter();
              }}
            >
              Apply Changes
            </Button>
          </DrawerFooter>
        </DrawerContent>
      </Drawer>
    </>
  );
};

export default Filter;
