import { Heading, Text, Card, CardBody, Box, Tag } from "@chakra-ui/react";
import { IMovie } from "./MovieSection";
import { BsMusicNoteList } from "react-icons/bs";
import { IoLocationSharp } from "react-icons/io5";
import { FaLanguage } from "react-icons/fa";
import DEFAULT_IMG from "../../assets/deafult_img.jpg";
import React from "react";

interface Props {
  movie: IMovie;
}

interface TagsProps {
  contentArray: string[];
  limit: number;
  title: string;
  icon: React.ReactNode;
}

const Tags: React.FC<TagsProps> = ({ contentArray, limit, title, icon }) => {
  return (
    <Box display={"flex"} flexDir={"column"} gap={"5px"}>
      <Box display={"flex"} gap={"5px"} alignItems={"center"}>
        {icon}
        <Text>{title}</Text>
      </Box>

      <Box display={"flex"} flexWrap={"wrap"} gap={"6px"}>
        {contentArray.slice(0, limit).map((elem: string, i: number) => {
          return <Tag key={`${elem}-${i}`}>{elem}</Tag>;
        })}

        {contentArray.length > limit && (
          <Text fontSize={"14px"}>+{contentArray.length - limit} more</Text>
        )}
      </Box>
    </Box>
  );
};

export default function MovieCard({ movie }: Props) {
  const {
    movietitle,
    moviecountries,
    moviegenres,
    movielanguages,
    moviemainphotos,
  } = movie;
  return (
    <Card
      direction="column"
      overflow="hidden"
      variant="outline"
      bg={"secondaryBgColor"}
      width={{ base: "90%", sm: "90%", md: "20%", lg: "20%" }}
    >
      <Box
        width={"100%"}
        height={"250px"}
        backgroundImage={moviemainphotos[0] ? moviemainphotos[0] : DEFAULT_IMG}
        backgroundRepeat={"no-repeat"}
        backgroundSize={"cover"}
        backgroundPosition={"center"}
      ></Box>

      <CardBody display={"flex"} flexDir={"column"} gap={"10px"}>
        <Heading size="md">{movietitle}</Heading>

        {moviegenres.length > 0 && (
          <Tags
            contentArray={moviegenres}
            limit={3}
            icon={<BsMusicNoteList />}
            title="Genres"
          />
        )}

        {moviecountries.length > 0 && (
          <Tags
            title="Countries"
            icon={<IoLocationSharp />}
            contentArray={moviecountries}
            limit={3}
          />
        )}

        {movielanguages.length > 0 && (
          <Tags
            title="Languages"
            icon={<FaLanguage />}
            contentArray={movielanguages}
            limit={3}
          />
        )}
      </CardBody>
      {/* <CardFooter>
        <Button color={"subText"}>View more</Button>
      </CardFooter> */}
    </Card>
  );
}
