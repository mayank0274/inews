import React, { useEffect, useRef, useState } from "react";
import { Box, Button, Center, Heading, Spinner, Text } from "@chakra-ui/react";
import MovieCard from "./MovieCard";
// import MOVIES_LIST from "../../constatnts/movies-filter-react.json";
import InfiniteScroll from "react-infinite-scroll-component";
import Filter from "./Filter";

type Props = {};

export interface IMovie {
  movietitle: string;
  imdbmovieid: string;
  movielanguages: string[];
  moviecountries: string[];
  moviemainphotos: string[];
  moviegenres: string[];
}

export interface IMoveList {
  "1": IMovie[];
  "2": IMovie[];
  "3": IMovie[];
  "4": IMovie[];
  "5": IMovie[];
  totalLength: number;
  [key: string]: IMovie[] | number;
}

const EndMessage: React.FC<{
  topElemRef: React.RefObject<HTMLDivElement>;
}> = ({ topElemRef }) => {
  return (
    <Center>
      Looks like you reach end of page!!{" "}
      <Button
        mx={"5px"}
        onClick={() => {
          if (topElemRef.current) {
            topElemRef.current.scrollIntoView();
          }
        }}
      >
        Go to top
      </Button>
    </Center>
  );
};

export const MovieSection: React.FC<Props> = () => {
  const [moviesList, setMoviesList] = useState<IMoveList | null>(null);
  const [movies, setMovies] = useState<IMovie[] | null>([]);
  const [page, setpage] = useState<string>("1");
  const [dataLength, setDataLength] = useState(0);
  const topElemRef = useRef<HTMLDivElement>(null);

  const fetchData = async () => {
    const res = await fetch("data2.json", {
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
    });

    const data = await res.json();

    setMoviesList(data);
    setDataLength(data.totalLength);
    setMovies(data["1"]);
    setpage("2");
  };

  useEffect(() => {
    fetchData();
  }, []);

  function handleNext() {
    if (moviesList && movies) {
      console.log(moviesList);
      const target = moviesList[page] as IMovie[];
      setMovies([...movies, ...target]);
    }
  }

  return (
    <Box my={"10px"}>
      <InfiniteScroll
        dataLength={movies?.length!}
        next={handleNext}
        hasMore={movies?.length != dataLength}
        loader={
          <Center>
            <Spinner size={"md"} />
          </Center>
        }
        endMessage={<EndMessage topElemRef={topElemRef} />}
        height={900}
      >
        <Box
          display={"flex"}
          justifyContent={"space-between"}
          alignItems={"center"}
          width={{ base: "90%", sm: "90%", md: "80%", lg: "80%" }}
          margin={"auto"}
        >
          <Heading
            fontFamily={"'Poppins', sans-serif"}
            textTransform={"capitalize"}
            textAlign={"center"}
            color={"primaryHeading"}
            as={"h2"}
            fontSize={{ base: "20px", sm: "20px", md: "25px", lg: "25px" }}
          >
            Explore Movies
          </Heading>
          <Filter
            setDataLength={setDataLength}
            setMovies={setMovies}
            moviesList={moviesList}
          />
        </Box>

        <Box
          display={"flex"}
          flexDir={{ base: "column", sm: "column", md: "row", lg: "row" }}
          gap={"10px"}
          flexWrap={"wrap"}
          justifyContent={"center"}
          alignItems={{
            base: "center",
            sm: "center",
            md: "normal",
            lg: "normal",
          }}
          my={"20px"}
          as="div"
        >
          <Box ref={topElemRef} as="div"></Box>
          {movies?.length === 0 && (
            <Text fontSize={"18px"}>
              No movies found !! Try With Clearing Filters{" "}
            </Text>
          )}
          {movies &&
            movies?.length > 0 &&
            movies.map((movie: IMovie, i: number) => {
              return (
                <MovieCard movie={movie} key={`${movie.imdbmovieid}-${i}`} />
              );
            })}
        </Box>
      </InfiniteScroll>
    </Box>
  );
};
