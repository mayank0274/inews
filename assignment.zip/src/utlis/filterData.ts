import { IConstraints } from "../components/movie/Filter";
import { IMovie } from "../components/movie/MovieSection";
import movieList from "../../public/data.json";

const data: IMovie[] = movieList;

export const filterData = (constraints: IConstraints): IMovie[] | [] => {
  const { countries, languages, genres } = constraints;
  let filterArr: IMovie[] = [];

  // if no filter
  if (!countries && !languages && !genres) {
    return [];
  }

  // if all three selected
  if (countries && languages && genres) {
    filterArr = data.filter((elem: IMovie) => {
      return (
        elem.moviecountries.includes(countries) &&
        elem.moviegenres.includes(genres) &&
        elem.movielanguages.includes(languages)
      );
    });
    return filterArr as IMovie[];
  }

  // if lang and genre
  if (languages && genres) {
    filterArr = data.filter((elem: IMovie) => {
      return (
        elem.moviegenres.includes(genres) &&
        elem.movielanguages.includes(languages)
      );
    });
    return filterArr as IMovie[];
  }

  // lang and country
  if (countries && languages) {
    filterArr = data.filter((elem: IMovie) => {
      return (
        elem.moviecountries.includes(countries) &&
        elem.movielanguages.includes(languages)
      );
    });
    return filterArr as IMovie[];
  }

  // genre and country
  if (genres && countries) {
    filterArr = data.filter((elem: IMovie) => {
      return (
        elem.moviecountries.includes(countries) &&
        elem.moviegenres.includes(genres)
      );
    });

    return filterArr as IMovie[];
  }

  // lang and genre
  if (languages && genres) {
    filterArr = data.filter((elem: IMovie) => {
      return (
        elem.moviegenres.includes(genres) &&
        elem.movielanguages.includes(languages)
      );
    });
    return filterArr as IMovie[];
  }

  // only lang
  if (languages) {
    filterArr = data.filter((elem: IMovie) => {
      return elem.movielanguages.includes(languages);
    });
    return filterArr as IMovie[];
  }

  // only genre
  if (genres) {
    filterArr = data.filter((elem: IMovie) => {
      return elem.moviegenres.includes(genres);
    });
    return filterArr as IMovie[];
  }

  // only country
  if (countries) {
    filterArr = data.filter((elem: IMovie) => {
      return elem.moviecountries.includes(countries);
    });
    return filterArr as IMovie[];
  }

  return filterArr as IMovie[];
};

export const getAllLanguages = (): string[] => {
  if (!data) {
    return [];
  }
  let languages: string[] = [];

  data.forEach((elem: IMovie) => {
    languages = [...languages, ...elem.movielanguages];
  });

  return [...new Set(languages)];
};

export const getAllCountries = (): string[] => {
  if (!data) {
    return [];
  }

  let countries: string[] = [];

  data.forEach((elem: IMovie) => {
    countries = [...countries, ...elem.moviecountries];
  });

  return [...new Set(countries)];
};

export const getAllGenres = (): string[] => {
  if (!data) {
    return [];
  }

  let genres: string[] = [];

  data.forEach((elem: IMovie) => {
    genres = [...genres, ...elem.moviegenres];
  });

  return [...new Set(genres)];
};
