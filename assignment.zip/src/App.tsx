import { Box } from "@chakra-ui/react";
import { Navbar } from "./components/layout/Navbar";
import { MovieSection } from "./components/movie/MovieSection";

function App() {
  return (
    <Box display={"flex"} flexDir={"column"} as="div">
      <Navbar />
      <MovieSection />
    </Box>
  );
}

export default App;
